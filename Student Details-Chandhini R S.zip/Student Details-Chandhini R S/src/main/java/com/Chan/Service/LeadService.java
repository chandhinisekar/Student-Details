package com.Chan.Service;

import java.util.List;

import com.Chan.Entity.Leads; 

public interface LeadService {

	public void saveleadinfo(Leads lead);

	public List<Leads> getAllLeads();

	public void deleteonelead(long id);

	public Leads updatelead(long id);


	public void updateLeadData(Leads lead1);


	






	


	
	
	
	
	
}
