package com.Chan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChanApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChanApplication.class, args);
	}

}
