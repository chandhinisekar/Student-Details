package com.Chan.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Chan.Entity.Leads;

public interface LeadRepository extends JpaRepository<Leads, Long> {
	

}
